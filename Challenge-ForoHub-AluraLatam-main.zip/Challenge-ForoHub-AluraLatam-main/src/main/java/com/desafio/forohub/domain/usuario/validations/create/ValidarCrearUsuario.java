package com.desafio.forohub.domain.usuario.validations.create;

import com.desafio.forohub.domain.usuario.dto.CrearUsuarioDTO;

public interface ValidarCrearUsuario {
    void validate(CrearUsuarioDTO data);
}
