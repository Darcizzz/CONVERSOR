package com.desafio.forohub.domain.topico.validations.create;

import com.desafio.forohub.domain.topico.dto.CrearTopicoDTO;

public interface ValidarTopicoCreado {

    void validate(CrearTopicoDTO data);
}
