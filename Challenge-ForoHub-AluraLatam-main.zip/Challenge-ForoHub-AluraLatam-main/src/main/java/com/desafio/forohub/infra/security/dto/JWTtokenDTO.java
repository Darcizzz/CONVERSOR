package com.desafio.forohub.infra.security.dto;

public record JWTtokenDTO(
        String JWTtoken
) {
}
