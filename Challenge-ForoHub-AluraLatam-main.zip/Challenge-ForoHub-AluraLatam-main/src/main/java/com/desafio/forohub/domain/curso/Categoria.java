package com.desafio.forohub.domain.curso;

public enum Categoria {
    FRONTEND,
    BACKEND,
    DEVOPS,
    ROBOTICS,
    IA
}